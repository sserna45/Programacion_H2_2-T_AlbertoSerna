<?php
session_start();
include('conexion.php');  

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    //Recibe y limpia los datos del formulario
    $email = trim($_POST['email']);
    $contraseña = $_POST['contraseña'];

    //Valida que los campos no estén vacíos
    if (empty($email) || empty($contraseña)) {
        $error = 'Todos los campos son obligatorios.';
    } else {
        // Verifica si el usuario existe en la base de datos
        $sql = "SELECT * FROM usuarios WHERE email = :email";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['email' => $email]);
        $user = $stmt->fetch();

        //Comprueba si la contraseña es correcta para ese usuario
        if ($user && password_verify($contraseña, $user['contraseña'])) {
            // Se inicia la sesión y se guarda la información del usuario
            $_SESSION['usuario_id'] = $user['id'];
            $_SESSION['nombre_usuario'] = $user['nombre_usuario'];
            
            // Redirige a la página de las tareas
            header("Location: tareas.php");
            exit();
        } else {
            $error = 'Correo electrónico o contraseña incorrectos.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

    <h1>Iniciar Sesión</h1>
    <!-- Muestra un mensaje de error si las credenciales son incorrectas -->
    <?php if (!empty($error)): ?>
        <p style="color: red;"><?php echo $error; ?></p>
    <?php endif; ?>

    <!-- Formulario de inicio de sesión -->
    <form action="login.php" method="POST">
        <div>
            <label for="email">Correo Electrónico:</label>
            <input type="email" name="email" required>
        </div>
        <div>
            <label for="contraseña">Contraseña:</label>
            <input type="password" name="contraseña" required>
        </div>
        <div>
            <button type="submit">Iniciar Sesión</button>
        </div>
    </form>

    <p>¿No tienes una cuenta? <a href="registro.php">Regístrate aquí</a></p>

</body>
</html>

