<?php
session_start(); //Iniciar la sesión para poder utilizarla (se incluye en todos los archivos)
session_unset(); // Elimina todas las variables de dicha sesión
session_destroy(); // Destruye la sesión
header("Location: index.php"); // Redirige al usuario a la página principal después de cerrar la sesión
exit();
?>


