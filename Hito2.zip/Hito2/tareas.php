<?php
session_start();
include('conexion.php');  

if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php"); // Si no está registrado, te redirige al login
    exit();
}
// Obtener el ID del usuario autenticado
$usuario_id = $_SESSION['usuario_id'];

//Agrega una nueva tarea
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['nombre_tarea']) && isset($_POST['descripcion_tarea'])) {
    $nombre_tarea = trim($_POST['nombre_tarea']);
    $descripcion_tarea = trim($_POST['descripcion_tarea']);

    if (empty($nombre_tarea) || empty($descripcion_tarea)) {
        $error = 'Todos los campos son obligatorios.'; 
    } else {
        try {
            // Añade una nueva tarea en la base de datos
            $sql = "INSERT INTO tareas (usuario_id, nombre_tarea, descripcion_tarea) 
                    VALUES (:usuario_id, :nombre_tarea, :descripcion_tarea)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                'usuario_id' => $usuario_id,
                'nombre_tarea' => $nombre_tarea,
                'descripcion_tarea' => $descripcion_tarea
            ]);
            $success = 'Tarea agregada exitosamente.';
        } catch (PDOException $e) {
            $error = "Error en la base de datos: " . $e->getMessage();
        }
    }
}

// Marca una tarea como completada
if (isset($_GET['completar']) && is_numeric($_GET['completar'])) {
    $tarea_id = $_GET['completar'];
    try {
        $sql = "UPDATE tareas SET completada = TRUE WHERE id = :tarea_id AND usuario_id = :usuario_id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            'tarea_id' => $tarea_id,
            'usuario_id' => $usuario_id
        ]);
    } catch (PDOException $e) {
        $error = "Error en la base de datos: " . $e->getMessage();
    }
}

//Elimina una tarea 
if (isset($_GET['eliminar']) && is_numeric($_GET['eliminar'])) {
    $tarea_id = $_GET['eliminar'];
    try {
        $sql = "DELETE FROM tareas WHERE id = :tarea_id AND usuario_id = :usuario_id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            'tarea_id' => $tarea_id,
            'usuario_id' => $usuario_id
        ]);
    } catch (PDOException $e) {
        $error = "Error en la base de datos: " . $e->getMessage();
    }
}

//Obtener todas las tareas del usuario
$sql = "SELECT * FROM tareas WHERE usuario_id = :usuario_id ORDER BY id DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute(['usuario_id' => $usuario_id]);
$tareas = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mis Tareas</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <h2>Mis Tareas</h2>
    <?php if (!empty($error)): ?>
        <p style="color: red;"><?php echo $error; ?></p>
    <?php endif; ?>

    <?php if (!empty($success)): ?>
        <p style="color: green;"><?php echo $success; ?></p>
    <?php endif; ?>

    <!--Formulario para agregar nuevas tareas -->
    <h3>Agregar nueva tarea</h3>
    <form action="tareas.php" method="POST">
        <label for="nombre_tarea">Nombre de la tarea:</label>
        <input type="text" name="nombre_tarea" required>

        <label for="descripcion_tarea">Descripción de la tarea:</label>
        <textarea name="descripcion_tarea" required></textarea>

        <button type="submit">Agregar tarea</button>
    </form>

    <!--Lista de tareas pendientes -->
    <h3>Tareas pendientes</h3>
    <ul>
        <?php foreach ($tareas as $tarea): ?>
            <li>
                <?php echo htmlspecialchars($tarea['nombre_tarea']); ?>
                - <?php echo htmlspecialchars($tarea['descripcion_tarea']); ?>
                <?php if (!$tarea['completada']): ?>
                    <a href="tareas.php?completar=<?php echo $tarea['id']; ?>">Marcar como completada</a>
                <?php else: ?>
                    <span>(Completada)</span>
                <?php endif; ?>
                <a href="tareas.php?eliminar=<?php echo $tarea['id']; ?>">Eliminar</a>
            </li>
        <?php endforeach; ?>
    </ul>

    <!--Cierra sesión -->
    <p><a href="cerrar_sesion.php">Cerrar sesión</a></p>
</body>
</html>







