<?php
session_start(); // Inicia una sesión 
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestión de Tareas</title>
    <link rel="stylesheet" href="styles.css"> 
</head>
<body>
    <h1>Bienvenido</h1>

    <div class="container">
        <h2>Elige una opción:</h2>
        <a href="registro.php">Registrarse</a> <!-- Te lleva a la página de registro -->
        <a href="login.php">Iniciar Sesión</a> <!-- Te lleva a la página de inicio de sesión -->
    </div>
</body>
</html>


