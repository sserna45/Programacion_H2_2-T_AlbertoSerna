CREATE DATABASE hito_progra2;
USE hito_progra2;

CREATE TABLE usuarios (
	id INT AUTO_INCREMENT PRIMARY KEY,       
    nombre_usuario VARCHAR(50) NOT NULL,     
    email VARCHAR(100) NOT NULL UNIQUE,      
    contraseña VARCHAR(255) NOT NULL         
);


CREATE TABLE tareas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    nombre_tarea VARCHAR(255) NOT NULL,
    descripcion_tarea TEXT,
    completada BOOLEAN DEFAULT FALSE, 
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);



