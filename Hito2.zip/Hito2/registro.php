<?php
session_start();

include('conexion.php'); // Incluye el archivo de conexión a la base de datos
$error = "";
$success = "";

// Verifica si el formulario fue enviado con el método POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Recibe y limpia los datos del formulario
    $nombre_usuario = trim($_POST['nombre_usuario']);
    $email = trim($_POST['email']);
    $contraseña = $_POST['contraseña'];

    // Verifica que los campos no estén vacíos
    if (empty($nombre_usuario) || empty($email) || empty($contraseña)) {
        $error = 'Todos los campos son obligatorios.';
    } else {
        $contraseña_hash = password_hash($contraseña, PASSWORD_DEFAULT); // Encripta la contraseña y luego la almacena en la base de datos
        try {
            // Verifica si el correo ya está registrado en la base de datos
            $sql = "SELECT id FROM usuarios WHERE email = :email";                  
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':email', $email);
            $stmt->execute();

            if ($stmt->fetch()) {
                $error = 'El correo electrónico ya está registrado.';
            } else {
                // Agrega el nuevo usuario en la base de datos
                $sql = "INSERT INTO usuarios (nombre_usuario, email, contraseña) 
                        VALUES (:nombre_usuario, :email, :password_hash)";

                $stmt = $pdo->prepare($sql);
                $stmt->bindParam(':nombre_usuario', $nombre_usuario);
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':password_hash', $contraseña_hash);  
                $stmt->execute();

                $success = 'Usuario registrado exitosamente.';
            }
        } catch (PDOException $e) {
            $error = "Error en la base de datos: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Usuario</title>
    <link rel="stylesheet" href="styles.css"> 
</head>
<body>
    <h2>Registro de Usuario</h2>

    <!-- Muestra mensajes de error si existe alguno-->
    <?php if ($error): ?>
        <p style="color: red;"><?php echo $error; ?></p>
    <?php endif; ?>

    <!-- Muestra un mensaje de éxito si el registro se hizo correctamente -->
    <?php if ($success): ?>
        <p style="color: green;"><?php echo $success; ?></p>
    <?php endif; ?>

    <!-- Crea el formulario de registro de usuarios -->
    <form action="registro.php" method="POST">
        <label for="nombre_usuario">Nombre de Usuario:</label>
        <input type="text" name="nombre_usuario" required>

        <label for="email">Correo Electrónico:</label>
        <input type="email" name="email" required>

        <label for="contraseña">Contraseña:</label>
        <input type="password" name="contraseña" required>

        <button type="submit">Registrarse</button>
    </form>

    <p>¿Ya tienes cuenta? <a href="login.php">Inicia sesión aquí</a></p>
</body>
</html>
